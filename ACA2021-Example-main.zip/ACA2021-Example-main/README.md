# ACA2021-Example
An Example for Academic Writing, Norms, and Ethics
